# Mission Cadet — NDA Study Platform

A starter full-stack website for digital NDA study material with manual UPI payment verification.

## Features
- Responsive premium NDA-style landing page
- Books ₹129, Practice ₹99, PYQs ₹149 starter catalog
- Cart and order creation
- Manual UPI/QR payment workflow
- UTR + payment note submission
- Admin approval required before PDF access
- Student My Orders / My Library APIs
- Private PDF storage outside public directory
- Admin PDF upload endpoint
- SQLite database
- Login/register with hashed passwords and HTTP-only JWT cookie

## Run locally
1. Install Node.js 18+.
2. `npm install`
3. Set environment variables in production:
   - `JWT_SECRET`
   - `ADMIN_EMAIL`
   - `ADMIN_PASSWORD`
4. `npm start`
5. Open `http://localhost:3000`

Default development admin credentials if environment variables are not set:
- Email: `admin@missioncadet.local`
- Password: `ChangeMe123!`

**Change these immediately before deployment.**

## Before launch
- Replace `YOUR-UPI-ID@BANK` and support Gmail in `public/app.js` / `public/index.html`.
- Upload real PDFs using the admin endpoint after logging in as admin.
- Add real QR image for your UPI ID.
- Add your actual refund/terms/privacy policy.
- Configure HTTPS and a strong `JWT_SECRET`.
- For production, use a managed database/storage and payment gateway when ready.
- Verify that all PDFs and PYQ material are original or properly licensed for distribution.
